# JARVIS Android

Gemini Live API ile calisan sesli asistan (Kotlin + Jetpack Compose).

## Kurulum
1. Android Studio (Koala veya yenisi) ile bu klasoru ac; Gradle senkronizasyonunu bekle.
2. Telefonda calistir (emulatorde mikrofon sinirli olabilir).
3. Ayarlar > Gemini API anahtarini yapistir (ai.google.dev'den ucretsiz).
4. "Konus"a bas, mikrofon iznini ver, konus.

## Araclar
Saat/tarih, pil, zamanlayici, alarm, uygulama acma, internet aramasi, el feneri.
Yeni arac eklemek icin `Tools.kt` icinde bir `functionDeclaration` ve bir `when` dali ekle.

## Notlar
- Model adi Ayarlar'dan degistirilebilir; Google adi degistirirse buradan guncelle.
- Uygulama on plandayken calisir (arka plan servisi yok).
