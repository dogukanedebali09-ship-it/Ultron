package com.alpai.jarvis

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini Live API (BidiGenerateContent) icin WebSocket istemcisi. */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val voice: String,
    private val systemPrompt: String,
    private val tools: JSONArray,
    private val listener: Listener
) {
    interface Listener {
        fun onReady()
        fun onAudio(pcm24k: ByteArray)
        fun onInterrupted()
        fun onInputText(text: String)
        fun onOutputText(text: String)
        fun onTurnComplete()
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onClosed(reason: String?)
    }

    private val http = OkHttpClient.Builder()
        .pingInterval(20, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var ws: WebSocket? = null
    @Volatile private var ready = false
    @Volatile private var closedNotified = false

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(setupMessage().toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                notifyClosed(if (reason.isBlank()) "Baglanti kapandi ($code)" else reason)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                notifyClosed(t.message ?: "Baglanti hatasi")
            }
        })
    }

    private fun notifyClosed(reason: String?) {
        ready = false
        if (!closedNotified) {
            closedNotified = true
            listener.onClosed(reason)
        }
    }

    private fun setupMessage(): JSONObject {
        val generationConfig = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put(
                "speechConfig", JSONObject().put(
                    "voiceConfig", JSONObject().put(
                        "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)
                    )
                )
            )
        val setup = JSONObject()
            .put("model", model)
            .put("generationConfig", generationConfig)
            .put(
                "systemInstruction", JSONObject().put(
                    "parts", JSONArray().put(JSONObject().put("text", systemPrompt))
                )
            )
            .put("tools", tools)
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
        return JSONObject().put("setup", setup)
    }

    private fun handle(text: String) {
        val j = try { JSONObject(text) } catch (e: Exception) { return }

        if (j.has("setupComplete")) {
            ready = true
            listener.onReady()
            return
        }

        j.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) listener.onInterrupted()

            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")
                    if (!data.isNullOrEmpty()) listener.onAudio(Base64.decode(data, Base64.DEFAULT))
                }
            }
            sc.optJSONObject("inputTranscription")?.optString("text")
                ?.takeIf { it.isNotEmpty() }?.let(listener::onInputText)
            sc.optJSONObject("outputTranscription")?.optString("text")
                ?.takeIf { it.isNotEmpty() }?.let(listener::onOutputText)
            if (sc.optBoolean("turnComplete")) listener.onTurnComplete()
        }

        j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                listener.onToolCall(
                    c.optString("id"),
                    c.optString("name"),
                    c.optJSONObject("args") ?: JSONObject()
                )
            }
        }
    }

    fun sendAudio(pcm16k: ByteArray) {
        if (!ready) return
        val msg = JSONObject().put(
            "realtimeInput", JSONObject().put(
                "audio", JSONObject()
                    .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000")
            )
        )
        ws?.send(msg.toString())
    }

    fun sendToolResponse(id: String, name: String, result: JSONObject) {
        val msg = JSONObject().put(
            "toolResponse", JSONObject().put(
                "functionResponses", JSONArray().put(
                    JSONObject().put("id", id).put("name", name).put("response", result)
                )
            )
        )
        ws?.send(msg.toString())
    }

    fun close() {
        ready = false
        closedNotified = true
        ws?.close(1000, "bye")
        ws = null
    }
}
