package com.alpai.jarvis

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import android.provider.AlarmClock
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gemini'nin cagirabilecegi telefon araclari. */
object Tools {

    fun declarations(): JSONArray = JSONArray(
        """
        [{"functionDeclarations":[
          {"name":"get_datetime","description":"Su anki tarih ve saati verir."},
          {"name":"get_battery","description":"Pil yuzdesini verir."},
          {"name":"set_timer","description":"Geri sayim zamanlayicisi kurar.",
           "parameters":{"type":"OBJECT","properties":{
             "seconds":{"type":"INTEGER","description":"Sure, saniye cinsinden"},
             "label":{"type":"STRING","description":"Zamanlayici etiketi"}},
             "required":["seconds"]}},
          {"name":"set_alarm","description":"Belirli bir saate alarm kurar.",
           "parameters":{"type":"OBJECT","properties":{
             "hour":{"type":"INTEGER","description":"Saat, 0-23"},
             "minute":{"type":"INTEGER","description":"Dakika, 0-59"},
             "label":{"type":"STRING","description":"Alarm etiketi"}},
             "required":["hour","minute"]}},
          {"name":"open_app","description":"Telefonda bir uygulamayi adiyla acar.",
           "parameters":{"type":"OBJECT","properties":{
             "name":{"type":"STRING","description":"Uygulama adi"}},
             "required":["name"]}},
          {"name":"web_search","description":"Tarayicida internet aramasi yapar.",
           "parameters":{"type":"OBJECT","properties":{
             "query":{"type":"STRING","description":"Arama metni"}},
             "required":["query"]}},
          {"name":"flashlight","description":"El fenerini acar veya kapatir.",
           "parameters":{"type":"OBJECT","properties":{
             "on":{"type":"BOOLEAN","description":"true: ac, false: kapat"}},
             "required":["on"]}}
        ]}]
        """.trimIndent()
    )

    fun execute(ctx: Context, name: String, args: JSONObject): JSONObject = try {
        when (name) {
            "get_datetime" -> ok(
                "datetime",
                SimpleDateFormat("d MMMM yyyy EEEE, HH:mm", Locale("tr")).format(Date())
            )
            "get_battery" -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                ok("percent", bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
            }
            "set_timer" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, args.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "JARVIS"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(ctx, i)
                ok("status", "Zamanlayici kuruldu")
            }
            "set_alarm" -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, args.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, args.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, args.optString("label", "JARVIS"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(ctx, i)
                ok("status", "Alarm kuruldu")
            }
            "open_app" -> openApp(ctx, args.optString("name"))
            "web_search" -> {
                val i = Intent(Intent.ACTION_WEB_SEARCH)
                    .putExtra(SearchManager.QUERY, args.optString("query"))
                start(ctx, i)
                ok("status", "Arama acildi")
            }
            "flashlight" -> flashlight(ctx, args.optBoolean("on"))
            else -> error("Bilinmeyen arac: $name")
        }
    } catch (e: Exception) {
        error(e.message ?: "Arac hatasi")
    }

    private fun start(ctx: Context, i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun openApp(ctx: Context, query: String): JSONObject {
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = query.lowercase(Locale("tr")).trim()
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase(Locale("tr")).contains(q)
        } ?: return error("'$query' adli uygulama bulunamadi")
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return error("Uygulama acilamadi")
        start(ctx, i)
        return ok("status", match.loadLabel(pm).toString() + " acildi")
    }

    private fun flashlight(ctx: Context, on: Boolean): JSONObject {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        } ?: return error("Flas bulunamadi")
        cm.setTorchMode(id, on)
        return ok("status", if (on) "El feneri acildi" else "El feneri kapandi")
    }

    private fun ok(key: String, value: Any) = JSONObject().put(key, value)
    private fun error(msg: String) = JSONObject().put("error", msg)
}
