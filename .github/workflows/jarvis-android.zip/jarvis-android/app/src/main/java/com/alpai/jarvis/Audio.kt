package com.alpai.jarvis

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import java.util.concurrent.LinkedBlockingQueue

/** 16 kHz, mono, PCM16 mikrofon yakalama. */
class AudioRecorder {
    private var record: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var running = false

    @SuppressLint("MissingPermission")
    fun start(onChunk: (ByteArray) -> Unit) {
        val minBuf = AudioRecord.getMinBufferSize(
            16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val r = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, // yankilanma iptali icin
            16000,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBuf, 6400)
        )
        record = r
        r.startRecording()
        running = true
        thread = Thread {
            val buf = ByteArray(3200) // ~100 ms
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) onChunk(buf.copyOf(n))
            }
        }.also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(300)
        record?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        record = null
    }
}

/** 24 kHz, mono, PCM16 akisli oynatici. */
class AudioPlayer {
    private val queue = LinkedBlockingQueue<ByteArray>()
    private val track: AudioTrack
    private val worker: Thread
    @Volatile private var running = true

    init {
        val minBuf = AudioTrack.getMinBufferSize(
            24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(24000)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, 48000))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
        worker = Thread {
            while (running) {
                try {
                    val chunk = queue.take()
                    track.write(chunk, 0, chunk.size)
                } catch (_: InterruptedException) {
                    break
                }
            }
        }.also { it.start() }
    }

    fun write(pcm: ByteArray) {
        queue.offer(pcm)
    }

    /** Kullanici sozunu kestiginde sesi hemen sustur. */
    fun flush() {
        queue.clear()
        try {
            track.pause()
            track.flush()
            track.play()
        } catch (_: Exception) {}
    }

    fun stop() {
        running = false
        worker.interrupt()
        queue.clear()
        try { track.stop() } catch (_: Exception) {}
        track.release()
    }
}
