package com.alpai.jarvis

import android.app.Application
import android.content.Context
import android.media.AudioManager
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject

class JarvisViewModel(private val app: Application) : AndroidViewModel(app), GeminiLiveClient.Listener {

    enum class Status { IDLE, CONNECTING, LIVE }
    data class Line(val fromUser: Boolean, val text: String)

    val settings = Settings(app)
    val status = mutableStateOf(Status.IDLE)
    val lines = mutableStateListOf<Line>()
    val error = mutableStateOf<String?>(null)

    private var client: GeminiLiveClient? = null
    private var recorder: AudioRecorder? = null
    private var player: AudioPlayer? = null
    private var currentSide: Boolean? = null // true: kullanici, false: JARVIS
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun ui(block: () -> Unit) {
        viewModelScope.launch(Dispatchers.Main) { block() }
    }

    fun start() {
        if (status.value != Status.IDLE) return
        if (settings.apiKey.isBlank()) {
            error.value = "Once Ayarlar'dan Gemini API anahtarini gir."
            return
        }
        error.value = null
        status.value = Status.CONNECTING
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        @Suppress("DEPRECATION")
        audioManager.isSpeakerphoneOn = true
        player = AudioPlayer()
        client = GeminiLiveClient(
            apiKey = settings.apiKey,
            model = settings.model,
            voice = settings.voice,
            systemPrompt = Settings.SYSTEM_PROMPT,
            tools = Tools.declarations(),
            listener = this
        ).also { it.connect() }
    }

    fun stop() {
        recorder?.stop(); recorder = null
        player?.stop(); player = null
        client?.close(); client = null
        audioManager.mode = AudioManager.MODE_NORMAL
        @Suppress("DEPRECATION")
        audioManager.isSpeakerphoneOn = false
        currentSide = null
        status.value = Status.IDLE
    }

    private fun append(fromUser: Boolean, text: String) {
        if (currentSide == fromUser && lines.isNotEmpty()) {
            val last = lines.last()
            lines[lines.lastIndex] = last.copy(text = last.text + text)
        } else {
            lines.add(Line(fromUser, text.trimStart()))
            currentSide = fromUser
        }
    }

    // --- GeminiLiveClient.Listener ---

    override fun onReady() = ui {
        status.value = Status.LIVE
        val rec = AudioRecorder()
        recorder = rec
        rec.start { chunk -> client?.sendAudio(chunk) }
    }

    override fun onAudio(pcm24k: ByteArray) {
        player?.write(pcm24k)
    }

    override fun onInterrupted() {
        player?.flush()
    }

    override fun onInputText(text: String) = ui { append(true, text) }

    override fun onOutputText(text: String) = ui { append(false, text) }

    override fun onTurnComplete() = ui { currentSide = null }

    override fun onToolCall(id: String, name: String, args: JSONObject) {
        viewModelScope.launch(Dispatchers.Default) {
            val result = Tools.execute(app, name, args)
            client?.sendToolResponse(id, name, result)
        }
    }

    override fun onClosed(reason: String?) = ui {
        if (status.value != Status.IDLE) {
            error.value = reason
            stop()
        }
    }

    override fun onCleared() {
        stop()
    }
}
