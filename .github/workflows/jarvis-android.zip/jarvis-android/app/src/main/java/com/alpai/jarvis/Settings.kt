package com.alpai.jarvis

import android.content.Context

class Settings(context: Context) {
    private val prefs = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString("api_key", "") ?: ""
        set(v) = prefs.edit().putString("api_key", v.trim()).apply()

    // Model adi Google tarafinda degisebilir; gerekirse Ayarlar'dan guncelle.
    var model: String
        get() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) = prefs.edit().putString("model", v.trim().ifEmpty { DEFAULT_MODEL }).apply()

    var voice: String
        get() = prefs.getString("voice", DEFAULT_VOICE) ?: DEFAULT_VOICE
        set(v) = prefs.edit().putString("voice", v.trim().ifEmpty { DEFAULT_VOICE }).apply()

    companion object {
        const val DEFAULT_MODEL = "models/gemini-2.5-flash-native-audio-preview-09-2025"
        const val DEFAULT_VOICE = "Charon"
        const val SYSTEM_PROMPT =
            "Sen JARVIS'sin: kullanicinin telefonunda calisan, sesli bir yapay zeka asistani. " +
            "Varsayilan olarak Turkce konus. Kisa, dogal ve net yanit ver. " +
            "Telefonda bir sey yapman istendiginde (zamanlayici, alarm, uygulama acma, internette arama, " +
            "el feneri, saat, pil) ilgili araci cagir ve sonucu tek cumleyle soyle."
    }
}
